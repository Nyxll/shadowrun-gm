
import React from 'react';
import type { Character } from '../types';
import { Panel } from './common/Panel';
import { Button } from './common/Button';

interface CharacterSheetModalProps {
  character: Character;
  onClose: () => void;
}

const StatBox: React.FC<{ label: string; value: string | number }> = ({ label, value }) => (
  <div className="bg-black/50 p-3 border-l-2 border-cyan-500">
    <div className="text-xs uppercase text-cyan-400/80 tracking-widest">{label}</div>
    <div className="text-2xl font-bold text-cyan-300 text-glow">{value}</div>
  </div>
);

const Section: React.FC<{ title: string; children: React.ReactNode }> = ({ title, children }) => (
    <div className="mb-6">
        <h3 className="text-xl font-bold text-cyan-400 text-glow border-b-2 border-cyan-500/30 pb-2 mb-3 tracking-wider" style={{ fontFamily: "'Orbitron', sans-serif" }}>
            {title}
        </h3>
        {children}
    </div>
);

export const CharacterSheetModal: React.FC<CharacterSheetModalProps> = ({ character, onClose }) => {
  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <Panel className="w-full max-w-4xl h-[90vh] flex flex-col">
        <div className="flex justify-between items-start pb-4 border-b border-cyan-500/30">
            <div>
                 <h2 className="text-3xl font-bold text-cyan-300 text-glow tracking-widest" style={{ fontFamily: "'Orbitron', sans-serif" }}>{character.name}</h2>
                 <p className="text-cyan-400">{character.role}</p>
            </div>
            <Button onClick={onClose} variant="secondary">Close</Button>
        </div>
        
        <div className="flex-1 overflow-y-auto p-4 -mr-4 pr-8">
            <Section title="Attributes">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                    {Object.entries(character.stats).map(([key, value]) => (
                        <StatBox key={key} label={key} value={value} />
                    ))}
                </div>
            </Section>

            <div className="grid md:grid-cols-2 gap-8">
                <div>
                    <Section title="Skills">
                        <ul className="space-y-2">
                            {character.skills.map(skill => (
                                <li key={skill.name} className="flex justify-between bg-black/30 p-2">
                                    <span className="text-cyan-300">{skill.name}</span>
                                    <span className="font-bold text-cyan-200">{skill.rating}</span>
                                </li>
                            ))}
                        </ul>
                    </Section>
                </div>
                <div>
                    <Section title="Cyberware">
                        <ul className="space-y-3">
                            {character.cyberware.map(ware => (
                                <li key={ware.name} className="bg-black/30 p-3 border-l-2 border-purple-500">
                                    <p className="font-bold text-purple-300">{ware.name}</p>
                                    <p className="text-sm text-purple-400/80">{ware.description}</p>
                                </li>
                            ))}
                        </ul>
                    </Section>
                    
                    <Section title="Gear">
                        <ul className="list-disc list-inside text-cyan-400 space-y-1">
                            {character.gear.map(item => (
                                <li key={item}>{item}</li>
                            ))}
                        </ul>
                    </Section>
                </div>
            </div>
        </div>
      </Panel>
    </div>
  );
};
